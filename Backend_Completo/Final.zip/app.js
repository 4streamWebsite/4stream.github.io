if (process.env.NODE_ENV !== 'production'){
    require('dotenv').config()
}
const express=require("express");
const app=express();
const handlebars=require('express-handlebars')
const engine = require('engine-handlebars')(handlebars);
const bodyparser=require('body-parser')
const admin=require("./routes/admin")
const path= require("path")
const session=require("express-session")
const flash = require('connect-flash')
const Categoria=require('./models/Categoria')
const Filme=require('./models/Filme')
const user=require("./routes/users")
const User=require('./models/user');
const passport = require("passport");
const cookieParser=require("cookie-Parser")
require("./config/auth")(passport)


//config
    //session config
    app.use(session({
        secret:process.env.SESSION_SECRET,
        resave:false,
        name:'session.4stream.sid',
        saveUninitialized:false,
        cookie:  {maxAge: 30 * 60 * 1000}
    }))
    
    app.use(passport.initialize())
    app.use(passport.session())
    app.use(flash())

    //Middleware
    app.use(function(req,res,next) {
        res.locals.success_msg= req.flash("success_msg")
        res.locals.error_msg= req.flash("error_msg")
        res.locals.error=req.flash("error")
        res.locals.user= req.user || null;
        next()
    })
   
    //template engine handlebars   
    app.engine('handlebars', handlebars({defaultLayout: 'main',
        runtimeOptions: {
            allowProtoPropertiesByDefault: true,
            allowProtoMethodsByDefault: true,
        },
    }))
    app.set("view engine", "handlebars");
     
    //Body parser
    app.use(bodyparser.urlencoded({extended:false}))
    app.use(bodyparser.json())
    //public
    app.use(express.static(path.join(__dirname,"public")))
//connect to db
    const dbconnect=require(__dirname+ '/models/db.js')
//rotas
    app.get('/', function(req,res) {
        Filme.findAll().then((filmes)=>{
            res.render("index", {filmes:filmes})
        }).catch((err)=>{
            req.flash("error_msg","houve um erro intero desculpe")
            res.redirect("/404")
        })        
    })

    app.get("/categorias", (req,res)=>{
        Categoria.findAll().then((Categoria)=>{
            res.render("categorias/index", {Categoria:Categoria})
        }).catch((err)=>{
            req.flash("error_msg", "Ups houve um erro na lista de categorias")
            res.redirect("/")
        })
    })

    app.get("/users", (req,res)=>{
        User.findAll().then((users)=>{
            res.render("users/index", {users:users})
        }).catch((err)=>{
            req.flash("error_msg", "Ups houve um erro na lista de categorias")
            res.redirect("/")
        })
    })



    app.get("/404", (req,res)=>{
        res.send("erro 404!")
    })
    app.use('/admin', admin)
    app.use("/users", user)

    
    
app.listen(3000,function(){console.log("estou a correr deixa-me em paz, se der coco eu digo")})