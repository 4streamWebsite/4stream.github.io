const express = require ("express")
const router=express.Router()
const db = require('../models/db')
const Categoria=require('../models/Categoria')
const categoria = require("../models/Categoria")
const Filme=require('../models/Filme')
const User = require("../models/user")
const{eAdmin}= require("../helpers/eAdmin")




//Segmento Admin HomePage
router.get('/', eAdmin, function(req,res){
    res.render("admin/index")
})
// Dashboard
router.get('/admin', (req, res) =>
  res.render('admin', {
    user: req.body.nome
  })
);

//
//segmento de Filmes
router.get('/filmes',eAdmin,function(req,res) {
    Filme.findAll().then((filmes)=>{
        res.render("admin/filmes", {filmes:filmes})
    }).catch((err)=>{
        req.flash("error_msg", "Houve um erro pá... desculpa")
        res.redirect("/admin/filmes")
    })
    

})
router.get("/filmes/add", (req,res) =>{
    Categoria.findAll().then((Categoria)=>{
        res.render("admin/addfilmes", {Categoria:Categoria})
    }).catch((err)=>{
       req.flash("error_msg", "houve um erro" +err) 
       res.redirect("admin/addfilmes")
    })    
})
router.post("/filmes/novo",(req,res)=>{
    let erros=[]
    if(req.body.categoria=="0"){
        erros.push({etext:"Categoria inválida, tem te adicionar uma categoria primeiro"})
    }
    if(erros.length>0){
        res.render("admin/addfilmes", {erros:erros})
    }else{Filme.create({
        Nome:req.body.nome,
        NomePT:req.body.nomept,
        DuracaoFilme:req.body.duracao,
        AnoLancamento:req.body.anoL,
        CustoTotal:req.body.custoTotal, 
        categoria:req.body.categoria,   
        linkimdb:req.body.linkimdb
    }).then(function(){
        req.flash("success_msg","Filme Adicionado com sucesso")
        res.redirect('/admin/filmes')        
        console.log("Categoria salva com sucesso")
    }).catch(function(erro){
        req.flash("error_msg","Algo não esta certo foi apanhado no catch de adicção de filmes")
        res.send("opa deu porcaria tenta ver o codigo no novo Filme" +erro)
    })}   
})

router.get("/filmes/edit/:id", (req,res)=>{
    Filme.findOne({where:{'id':req.params.id}}).then(function(Filme) {
        Categoria.findAll().then(function(Categoria){
            res.render('admin/editfilmes',{Categoria:Categoria, Filme:Filme})
            
        }).catch((err)=>{
            req.flash("error_msg", "houve um erro a carregar as categorias")
            res.redirect("/admin/filmes")
            
            
        })
    }).catch(function(erro){
        req.flash("error_msg","opa deu porcaria tenta ver o codigo"+erro)
        res.redirect("/admin/filmes")
       })    
    
})
//Edição dos dados Filme [POST]
router.post("/filmes/edit", (req,res) =>{
    Filme.findOne({where:{'id':req.body.id}}).then(function(Filmes) {
        Filmes.update(
            {Nome:req.body.nome,
                NomePT:req.body.nomept,
                DuracaoFilme:req.body.duracao,
                AnoLancamento:req.body.anoL,
                CustoTotal:req.body.custoTotal, 
                categoria:req.body.categoria,   
                linkimdb:req.body.linkimdb
            } //nome do campo que vai ser trocado na bd tabela filmes
        )
        req.flash("success_msg","Editado com sucesso")
        res.redirect("/admin/filmes")
    }).catch(function (erro) {
        req.flash("error_msg", "houve um erro a editar o filme" +erro)
        res.redirect("/admin/filmes")
    })

})
router.post("/filmes/delete/",function(req,res){
    Filme.destroy({where:{'id':req.body.id}}).then(function(){
        req.flash("success_msg", "iupi apagaste me com sucesso")
        res.redirect("/admin/filmes")
    }).catch(function(erro){
        req.flash("error_msg","opa deu porcaria tenta ver o codigo não consigo apagar" +erro)
       res.redirect("/admin/filmes")
    })
})
//fim Segmento Filmes
//Segmento de Categorias
//pagina geral de categorias
router.get("/categorias",function(req,res) {
    Categoria.findAll().then(function(Categoria){
        res.render('admin/categorias',{Categoria: Categoria})
    }).catch(function(erro){
     req.flash("error_msg","opa deu porcaria tenta ver o codigo" +erro)
        res.redirect("/admin")
    })
})
//pagina de adicionar uma categoria
router.get('/categorias/add',function(req,res) {
    res.render('admin/addcategorias')
})
//pagina de edicao de categoria
router.get("/categorias/edit/:id",function (req,res){
    Categoria.findOne({where:{'id':req.params.id}}).then(function(Categoria) {
        res.render("admin/editcategorias", {Categoria:Categoria})
    }).catch(function(erro){
        req.flash("error_msg","opa deu porcaria tenta ver o codigo"+erro)
        res.redirect("/cat")
       })    
})
//pagina de delete de uma categoria
router.post("/categorias/delete/",function(req,res){
    Categoria.destroy({where:{'id':req.body.id}}).then(function(){
        req.flash("iupi apagaste me com sucesso")
        res.redirect("/admin/categorias")
    }).catch(function(erro){
        req.flash("error_msg","opa deu porcaria tenta ver o codigo não consigo apagar" +erro)
       res.redirect("/admin/categorias")
})
   
})
//envio de pedido de nova categoria ao precionar o envio do formulario [POST]
router.post("/categorias/nova",function(req,res) {
    var erros=[]
    if(!req.body.nome || typeof req.body.nome == undefined || req.body.nome==null){
        erros.push({etext:"nome é um dado requerido"})        
    }
    if(req.body.nome.length < 2){
        erros.push({etext:"nome demasiado curto"}) //etext texto de erro
    }
    if(erros.length >0){
        res.render("admin/addcategorias", {erros: erros})
    }else{Categoria.create({
        nome:req.body.nome    
    }).then(function(){
        req.flash("success_msg","Categoria salva com sucesso")
        res.redirect('/admin/categorias')        
        console.log("Categoria salva com sucesso")
    }).catch(function(erro){
        req.flash("error_msg","opa deu porcaria tenta ver o codigo")
        res.send("opa deu porcaria tenta ver o codigo" +erro)
    })}
       
})
//Edição de Categoria [POST]
router.post("/categorias/edit",function (req,res) {
    Categoria.findOne({where:{'id':req.body.id}}).then(function(Categoria) {
        Categoria.update(
            {nome:req.body.nome} //nome do campo que vai ser trocado na bd tabela categoria
        )
        req.flash("success_msg","Editado com sucesso")
        res.redirect("/admin/categorias")
    }).catch(function (erro) {
        req.flash("error_msg", "houve um erro a editar a categoria" +erro)
        res.redirect("/admin/categorias")
    })
})
//Segmento Users:

router.get('/users',function(req,res) {
    User.findAll().then((users)=>{
        res.render("admin/users", {users:users})
    }).catch((err)=>{
        req.flash("error_msg", "Houve um erro pá... desculpa")
        res.redirect("/admin/")
    })
    
//tornar admin

router.get("/users/edit/:id",function (req,res){
    User.findOne({where:{'id':req.params.id}}).then(function(users) {
        res.render("admin/editusers", {users:users})
    }).catch(function(erro){
        req.flash("error_msg","opa deu porcaria tenta ver o codigo"+erro)
        res.redirect("/admin/users")
       })    
})
router.post("/users/edit",function (req,res) {
    User.findOne({where:{'id':req.body.id}}).then(function(users) {
        users.update(
            {nome:req.body.nome,
            email:req.body.email,
            eAdmin:req.body.eAdmin
            } //nome do campo que vai ser trocado na bd tabela categoria
        )
        req.flash("success_msg","User editado com sucesso")
        res.redirect("/admin/users")
    }).catch(function (erro) {
        req.flash("error_msg", "houve um erro a editar a categoria" +erro)
        res.redirect("/admin/users")
    })
})                        


//pagina de delete de um user
router.post("/users/delete/",function(req,res){
    User.destroy({where:{'id':req.body.id}}).then(function(){
        req.flash("iupi apagaste me com sucesso")
        res.redirect("/admin/users")
    }).catch(function(erro){
        req.flash("error_msg","opa deu porcaria tenta ver o codigo não consigo apagar" +erro)
       res.redirect("/admin/")
    })
})


})
module.exports=router