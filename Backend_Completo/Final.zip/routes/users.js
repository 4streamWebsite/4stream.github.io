const express = require ("express")
const router=express.Router()
const db = require('../models/db')
const user=require("../models/user")
const bcrypt=require("bcrypt")
const User = require("../models/user")
const passport = require("passport")
const nodemailer=require("nodemailer")

let transporter=nodemailer.createTransport({
    host: 'smtp.gmail.com',
    port: 465,
    secure: true, // use SSL
    auth: {
        user: '4streamual@gmail.com',
        pass: '4Stream.Life'
    }
})

router.get("/registo", (req,res)=>{
    res.render("users/registo")
})

router.post("/registo",  (req,res)=>{
    let erros=[]
    if(!req.body.nome || typeof req.body.nome == undefined || req.body.nome==null){
        erros.push({etext: "Nome Invalido"})
    }
    if(!req.body.email || typeof req.body.email == undefined || req.body.email==null){
        erros.push({etext: "Nome Email Invalido"})
    }
    if(req.body.password.length < 4){
        erros.push({etext: "Password é demasiado curta"})
    }
    if(req.body.password != req.body.password2){
        erros.push({etext: "As Passwords não são iguais"})
    }

    if(erros.length >0){
        res.render("users/registo", {erros:erros})
    }else{
        user.findOne({where:{email:req.body.email}}).then((user)=>{
            if(user){
                req.flash("error_msg", "já existe 4Streamer registado com esse email tenta antes fazer login ou reset da pass ")
                res.redirect("/")
            }else{
                var template={nome:req.body.nome,email:req.body.email}
                bcrypt.hash(req.body.password, 10, (err,hash)=>{
                    User.create({
                        email:req.body.email,
                        nome:req.body.nome,
                        password:hash,
                        username:req.body.username
                    })
                transporter.sendMail({
                    from: "4Stream <4streamual@gmail.com>",
                    to: req.body.email,
                    subject:" Bem vindo ao 4Stream",
                    text: "olá, bem vindo 4streamer",
                    html:"<img src='https://i.ibb.co/VTsN8Q1/Logo4.png' style='width: 100px' alt='4Stream Logo'/><br>Olá 4streamer</h4<br><h4>Bem vindo ao maior site de Streaming nacional</h4><br><p>a tua conta esta confirmada</p><a href='http://www.4stream.website/login'> clicka aqui para fazeres login</a>" 
                    
                }).then(message=>{
                    console.log(message);
                }).catch(err=>{
                    console.log(err)
                })
                })
                req.flash('success_msg', 'Conta 4Stream registada, vai ao teu email para confirmar a tua conta')
                res.redirect('/users/login')
            }
            
        }).catch((err)=>{
            req.flash("erro_msg", "Houve um erro interno no registo")
            res.redirect("/")  
        })
    }
})
router.get("/login", (req,res)=>{
    res.render("users/login")
})

router.post('/login', (req, res, next) => {
    passport.authenticate('local', {
      successRedirect: '/',
      failureRedirect: '/users/login',
      failureFlash: true,
      successFlash: true 
    })(req, res, next);
  });

  router.get('/logout', (req, res) => {
    req.logout();
    req.flash('success_msg', 'Até a próxima B4Streamer');
    res.redirect('/users/login');
  });
  



module.exports=router