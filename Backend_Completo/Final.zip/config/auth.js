const LocalStrategy = require('passport-local').Strategy;
const bcrypt = require('bcryptjs');

// Load User model
const User = require('../models/User');

module.exports = function(passport) {
  passport.use(
    new LocalStrategy({ usernameField: 'email' }, (email, password, done) => {
      // Match user
      User.findOne({where:{
        email: email
      }}).then(user => {
        if (!user) {
          return done(null, false, { message: 'Humm este emaill não esta registado' });
        }

        // Match password
        bcrypt.compare(password, user.password, (err, isMatch) => {
          if (err) throw err;
          if (isMatch) {
            return done(null, user);
          } else {
            return done(null, false, { message: 'Password parece Incorrecta' });
          }
        });
      });
    })
  );

  /*passport.serializeUser(function(user, done) {
    done(null, User.email);
  });

  passport.deserializeUser(function(id, done) {
    User.findById(email, function(err, user) {
      done(err, User);
    });
  });*/

  passport.serializeUser(function(user, done) {
    done(null, user);
  });
  
  passport.deserializeUser(function(user, done) {
    done(null, user);
  });
};